import { Link, Head } from '@inertiajs/react';

export default function Welcome({ auth }) {
    return (
        <>
            <Head title="Selamat Datang ke SISDA" />
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-zinc-900 dark:to-zinc-800 flex flex-col items-center justify-center relative overflow-hidden">
                {/* Decorative background elements */}
                <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
                    <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] rounded-full bg-blue-500/10 blur-3xl"></div>
                    <div className="absolute top-[40%] -right-[10%] w-[40%] h-[40%] rounded-full bg-purple-500/10 blur-3xl"></div>
                    <div className="absolute -bottom-[10%] left-[20%] w-[30%] h-[30%] rounded-full bg-teal-500/10 blur-3xl"></div>
                </div>

                <div className="relative z-10 w-full max-w-md px-6">
                    <div className="bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl rounded-3xl shadow-2xl p-8 border border-white/20 dark:border-zinc-700/50 transform transition-all hover:scale-[1.01] duration-500">
                        
                        {/* Logo Section */}
                        <div className="flex justify-center mb-8">
                            <div className="relative group">
                                <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                                <img 
                                    src="/images/logo-sisda.png" 
                                    alt="SISDA Logo" 
                                    className="relative h-24 w-auto object-contain drop-shadow-md transform transition duration-500 group-hover:rotate-3"
                                />
                            </div>
                        </div>

                        {/* Title Section */}
                        <div className="text-center mb-10">
                            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 mb-2">
                                SISDA
                            </h1>
                            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium tracking-wide uppercase">
                                Sistem Data Pengundi
                            </p>
                        </div>

                        {/* Action Buttons */}
                        <div className="space-y-4">
                            {auth.user ? (
                                <Link
                                    href={route('dashboard')}
                                    className="block w-full text-center py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white font-semibold shadow-lg shadow-blue-500/30 transition-all duration-300 hover:shadow-blue-500/50 hover:-translate-y-0.5 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-zinc-900"
                                >
                                    Masuk ke Dashboard
                                </Link>
                            ) : (
                                <>
                                    <Link
                                        href={route('login')}
                                        className="block w-full text-center py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold shadow-lg shadow-blue-500/30 transition-all duration-300 hover:shadow-blue-500/50 hover:-translate-y-0.5 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-zinc-900"
                                    >
                                        Log Masuk
                                    </Link>
                                    
                                    <div className="relative flex py-2 items-center">
                                        <div className="flex-grow border-t border-slate-200 dark:border-zinc-700"></div>
                                        <span className="flex-shrink-0 mx-4 text-slate-400 text-xs uppercase tracking-wider">atau</span>
                                        <div className="flex-grow border-t border-slate-200 dark:border-zinc-700"></div>
                                    </div>

                                    <Link
                                        href={route('register')}
                                        className="block w-full text-center py-3.5 px-6 rounded-xl bg-white dark:bg-zinc-800 text-slate-700 dark:text-slate-200 font-semibold border border-slate-200 dark:border-zinc-700 shadow-sm hover:bg-slate-50 dark:hover:bg-zinc-700/50 transition-all duration-300 hover:border-slate-300 dark:hover:border-zinc-600 hover:-translate-y-0.5 focus:ring-2 focus:ring-slate-200 dark:focus:ring-zinc-700 focus:ring-offset-2 dark:focus:ring-offset-zinc-900"
                                    >
                                        Daftar Akaun Baru
                                    </Link>
                                </>
                            )}
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="mt-8 text-center">
                        <p className="text-slate-400 dark:text-zinc-500 text-xs">
                            &copy; {new Date().getFullYear()} SISDA. Hak Cipta Terpelihara.
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}
