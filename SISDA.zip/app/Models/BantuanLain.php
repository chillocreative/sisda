<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BantuanLain extends Model
{
    use HasFactory;

    protected $table = 'bantuan_lain';

    protected $fillable = [
        'nama',
        'bandar_id',
        'sort_order',
    ];

    public function bandar()
    {
        return $this->belongsTo(Bandar::class);
    }

    protected static function booted()
    {
        static::addGlobalScope('ordered', function ($builder) {
            $builder->orderBy('sort_order', 'asc')->orderBy('id', 'asc');
        });
    }
}
